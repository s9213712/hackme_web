# 只提交相對於 hackme_web 的差異

## 原則

本專案只提交相對 `hackme_web` 的變更，不提交整份未修改專案。

## 檢查

```bash
git remote add upstream https://github.com/s9213712/hackme_web.git
git fetch upstream
git diff upstream/main --stat
git diff upstream/main
```

## 允許

- `services/ai_*.py`
- `routes/ai_control.py`
- `scripts/ai_*.py`
- `tests/test_ai_mvp.py`
- `docs/*`
- README 更新
- route registration 小修改

## 禁止

- database runtime
- logs
- storage
- snapshots
- `.env`
- secrets
- 未修改原始碼
