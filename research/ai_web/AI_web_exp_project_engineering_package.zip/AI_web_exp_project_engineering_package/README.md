# AI-Controlled Web Platform（AI_web_exp_project）

本專案是 **基於 `hackme_web` 的 AI 管理實驗網站**。

原始基底：

```text
https://github.com/s9213712/hackme_web
```

AI_web_exp_project 的目標是在 `hackme_web` 上新增 AI 管理層：

- AI 分析 audit / security / integrity / health
- AI 產生報告
- AI 提出 action proposal
- AI 可執行低風險 allowlist action
- 中高風險操作需 root 核准
- root 永遠高於 AI
- AI 永遠不可碰 root 帳號

---

## 1. 建立專案

```bash
git clone https://github.com/s9213712/hackme_web.git AI_web_exp_project
cd AI_web_exp_project
git checkout -b ai_controlled_platform
git remote add upstream https://github.com/s9213712/hackme_web.git
git fetch upstream
```

---

## 2. 套用 AI overlay

將本壓縮包中的 `overlay/` 套進 repo。

自動套用：

```bash
python3 overlay/scripts/apply_ai_mvp_overlay.py --repo .
```

手動套用：

```bash
cp -R overlay/services/* services/
cp -R overlay/routes/* routes/
cp -R overlay/scripts/* scripts/
cp -R overlay/tests/* tests/
cp -R overlay/docs/* docs/
cp -R overlay/public/* public/
cp -R overlay/database/* database/
cp overlay/.env.ai.example .
```

修改 `routes/operations.py`：

```python
from routes.ai_control import register_ai_control_routes
```

並在 `register_operation_routes(app, deps)` 中加入：

```python
register_ai_control_routes(app, deps)
```

---

## 3. 安裝依賴

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

---

## 4. 啟動網站

```bash
export HTML_LEARNING_ROOT_PASSWORD='change-this-root-password'
python3 server.py
```

---

## 5. 啟用 AI

MVP 預設使用 dryrun：

```bash
export AI_CONTROLLER_ENABLED=true
export AI_LLM_PROVIDER=dryrun
```

或在 `system_settings` 中設定：

```text
ai_controller_enabled = true
ai_mode = assistive
ai_llm_provider = dryrun
```

---

## 6. Ollama

```bash
ollama serve
ollama pull llama3.1

export AI_CONTROLLER_ENABLED=true
export AI_LLM_PROVIDER=ollama
export AI_LLM_BASE_URL=http://127.0.0.1:11434
export AI_LLM_MODEL=llama3.1
```

---

## 7. LM Studio

在 LM Studio 啟用 Local Server。

```bash
export AI_CONTROLLER_ENABLED=true
export AI_LLM_PROVIDER=lmstudio
export AI_LLM_BASE_URL=http://127.0.0.1:1234
export AI_LLM_MODEL=local-model
```

---

## 8. OpenClaw

建議：

```text
AI_web_exp_project → OpenClaw Gateway → Ollama / LM Studio
```

若 OpenClaw 提供 OpenAI-compatible endpoint：

```bash
export AI_CONTROLLER_ENABLED=true
export AI_LLM_PROVIDER=openai_compatible
export AI_LLM_BASE_URL=http://127.0.0.1:18789/v1
export AI_LLM_MODEL=openclaw-local
```

若 OpenClaw 是 WebSocket gateway，MVP 請先用 local HTTP relay；下一階段可加入 WebSocket client。

---

## 9. Smoke test

```bash
python3 scripts/ai_mvp_smoke.py
```

預期：

```text
AI MVP smoke passed
```

---

## 10. Pytest

```bash
PYTHONPATH=. python3 -m pytest -q tests/test_ai_mvp.py
```

---

## 11. 只提交差異

```bash
git diff upstream/main --stat
git diff upstream/main
```

只提交：

- 新增 AI 檔案
- 必要修改檔案
- docs / tests / scripts

不要提交：

- 原始未修改檔案
- runtime data
- `.env`
- secrets

---

## 12. 安全限制

AI 永遠不可：

- 操作 root 帳號
- 修改 root 密碼
- revoke root session
- 讀 raw secrets
- 執行 shell
- 執行 SQL
- 解密 E2EE
- 下載私有檔案
- 刪除 audit log
- 關閉 Integrity Guard

root 永遠可以：

- 關閉 AI
- 審核 AI
- override AI
- 回滾 AI 行為

---

## 13. API

```text
GET  /api/root/ai/status
POST /api/root/ai/analyze
GET  /api/root/ai/reports
GET  /api/root/ai/proposals
POST /api/root/ai/proposals/<id>/approve
POST /api/root/ai/proposals/<id>/execute
POST /api/root/ai/kill-switch
```

---

## 14. 結論

AI 是副駕，root 是駕駛。
