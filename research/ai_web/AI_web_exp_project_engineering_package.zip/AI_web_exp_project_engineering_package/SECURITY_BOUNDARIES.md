# AI 安全邊界

## root 永遠最高

AI 不可操作：

- root 帳號
- root 密碼
- root session
- root role
- root MFA/recovery
- root private data

## AI 禁止

- shell
- SQL
- raw secret
- private file download
- E2EE decrypt
- audit deletion
- integrity disable
- SMTP/Discord token modification

## AI 執行必經流程

```text
proposal → approval → executor validate → execute → audit
```

## Executor 原則

- allowlist only
- fixed schema only
- no arbitrary file path
- no shell
- no SQL
