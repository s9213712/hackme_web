# 超細粒度 Agent 任務（逐檔實作）

## Phase 0：基底準備

```bash
git clone https://github.com/s9213712/hackme_web.git AI_web_exp_project
cd AI_web_exp_project
git checkout -b ai_controlled_platform
git remote add upstream https://github.com/s9213712/hackme_web.git
git fetch upstream
```

---

## Phase 1：新增 AI Schema

新增：

```text
services/ai_schema.py
database/ai_control.schema.sql
```

任務：

1. 建立 `ai_sessions`
2. 建立 `ai_analysis_reports`
3. 建立 `ai_action_proposals`
4. 建立 `ai_tool_events`
5. seed AI settings：
   - `feature_ai_admin_lab_enabled`
   - `ai_controller_enabled`
   - `ai_mode`
   - `ai_llm_provider`
   - `ai_llm_base_url`
   - `ai_llm_model`
   - `ai_redact_secrets`
6. schema 必須 idempotent。

---

## Phase 2：新增 Redaction

新增：

```text
services/ai_redaction.py
```

任務：

1. 遮罩 password
2. 遮罩 token
3. 遮罩 Authorization header
4. 遮罩 Discord webhook
5. 遮罩 DB URL
6. 遮罩 private key
7. redacted context 才能送 LLM
8. redacted input/output 才能存 DB

---

## Phase 3：Action Registry

新增：

```text
services/ai_action_registry.py
```

任務：

1. 定義 action allowlist
2. 定義 forbidden actions
3. 每個 action 有 risk level
4. 每個 action 有 required fields
5. 驗證 payload schema
6. 若 payload 包含 `user_id`，查 DB 確認不是 root-protected。
7. forbidden action 一律拒絕。

---

## Phase 4：LLM Client

新增：

```text
services/ai_llm_client.py
```

任務：

1. 支援 dryrun
2. 支援 Ollama `/api/chat`
3. 支援 LM Studio `/v1/chat/completions`
4. 支援 OpenAI-compatible endpoint
5. timeout
6. 不 log token
7. failure safe

---

## Phase 5：AI Controller

新增：

```text
services/ai_controller.py
```

任務：

1. 收集 bounded context
2. context redaction
3. 呼叫 LLM client
4. 保存 report
5. 根據 context 建立 proposal
6. 提供 list reports / proposals

---

## Phase 6：AI Executor

新增：

```text
services/ai_executor.py
```

任務：

1. 執行 low-risk action
2. 中高風險必須 approved
3. 禁止 shell / SQL
4. 所有執行寫 `ai_tool_events`
5. root-protected target 必拒絕

MVP 實作：

- RUN_HEALTH_CHECK
- CREATE_DIAGNOSTIC_REPORT
- SUMMARIZE_SECURITY_EVENTS
- RUN_INTEGRITY_RESCAN no-op/callback
- ENABLE_MAINTENANCE_MODE with approval

---

## Phase 7：Root-only API

新增：

```text
routes/ai_control.py
```

API：

```text
GET  /api/root/ai/status
POST /api/root/ai/analyze
GET  /api/root/ai/reports
GET  /api/root/ai/proposals
POST /api/root/ai/proposals/<id>/approve
POST /api/root/ai/proposals/<id>/execute
POST /api/root/ai/kill-switch
```

要求：

- root-only
- CSRF
- audit
- no secrets in response

---

## Phase 8：Route registration

修改：

```text
routes/operations.py
```

加入：

```python
from routes.ai_control import register_ai_control_routes
```

並在 function 內加入：

```python
register_ai_control_routes(app, deps)
```

---

## Phase 9：UI Helper

新增：

```text
public/js/60-ai-control.js
```

MVP：

- status()
- analyze()
- reports()
- proposals()

---

## Phase 10：Smoke Script

新增：

```text
scripts/ai_mvp_smoke.py
```

測：

- schema
- redaction
- dryrun analysis
- health action
- forbidden action rejection
- root target rejection

---

## Phase 11：Tests

新增：

```text
tests/test_ai_mvp.py
```

測：

- redaction
- forbidden action
- root-protected target
- dryrun analysis
- executor health
- unapproved medium-risk reject

---

## Phase 12：Docs

新增：

```text
docs/ai_controlled_system.md
docs/openclaw_connection.md
```

---

## Phase 13：驗收命令

```bash
python3 scripts/ai_mvp_smoke.py
PYTHONPATH=. python3 -m pytest -q tests/test_ai_mvp.py
git diff upstream/main --stat
```
