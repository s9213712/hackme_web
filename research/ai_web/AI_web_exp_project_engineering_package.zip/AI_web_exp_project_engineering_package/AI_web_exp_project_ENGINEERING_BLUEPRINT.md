# AI_web_exp_project 工程級藍圖

## 0. 定位

本專案是 **基於 `hackme_web` 的實驗性 AI 管理網站**。

不是從零開始，不重造輪子，而是在既有 `hackme_web` 的：

- auth
- RBAC
- audit
- security_events
- Integrity Guard
- snapshots
- upload / cloud drive security
- admin / root operations

之上新增 **AI Controller / AI Executor / AI Decision Engine**。

核心原則：

```text
AI 是 automation layer，不是 root。
root 是最高權限，永遠可以關閉、覆寫、審核、回滾 AI。
AI 永遠不可操作 root 帳號。
```

---

## 1. 基底專案

```bash
git clone https://github.com/s9213712/hackme_web.git AI_web_exp_project
cd AI_web_exp_project
git checkout -b ai_controlled_platform
git remote add upstream https://github.com/s9213712/hackme_web.git
git fetch upstream
```

禁止從零開發。

---

## 2. 只提交差異

本專案交付時，只提交相對於 `hackme_web` 的變更：

允許：

- 新增 AI 模組
- 新增 routes
- 新增 docs
- 新增 tests
- 新增 scripts
- 必要的小範圍修改，例如 `routes/operations.py` 註冊 AI route

禁止：

- 提交未修改的 `hackme_web` 原始檔
- 提交 database / logs / storage / snapshots
- 提交 `.env`
- 提交 token / private key / SMTP password / Discord webhook

檢查：

```bash
git diff upstream/main --stat
git diff upstream/main
git status --short
```

---

## 3. 新增 repo 結構

套用本 package 的 `overlay/` 後，新增：

```text
services/
  ai_schema.py
  ai_redaction.py
  ai_action_registry.py
  ai_llm_client.py
  ai_controller.py
  ai_executor.py

routes/
  ai_control.py

scripts/
  apply_ai_mvp_overlay.py
  ai_mvp_smoke.py

tests/
  test_ai_mvp.py

docs/
  ai_controlled_system.md
  openclaw_connection.md

public/js/
  60-ai-control.js

database/
  ai_control.schema.sql
```

---

## 4. AI 執行資料流

```text
system events / audit / health / integrity findings
        ↓
redaction
        ↓
AI provider:
  - dryrun
  - Ollama
  - LM Studio
  - OpenClaw HTTP / OpenAI-compatible
        ↓
analysis report
        ↓
action proposal
        ↓
root approve / two-person approval
        ↓
server-side allowlisted executor
        ↓
audit + ai_tool_events
```

---

## 5. AI 模式

```text
assistive:
  只分析與提案，不執行

supervised:
  可執行低風險 action；中高風險需 root approve

autonomous-limited:
  僅低風險 allowlist 自動執行

autonomous-full:
  禁止
```

預設：

```text
ai_controller_enabled = false
ai_mode = assistive
ai_llm_provider = dryrun
```

---

## 6. Root 保護

AI 永遠不得操作 root。

判斷條件：

```text
username == root
role == super_admin
is_root_protected == 1
```

若 action payload 包含 `user_id`，executor 必須查 DB；若目標是 root-protected user，立即拒絕。

---

## 7. Action Allowlist

### 低風險

- RUN_HEALTH_CHECK
- RUN_INTEGRITY_RESCAN
- CREATE_DIAGNOSTIC_REPORT
- SUMMARIZE_SECURITY_EVENTS
- RUN_RETENTION_DRY_RUN

### 中風險，需 root approve

- ENABLE_MAINTENANCE_MODE
- DISABLE_DISCORD_SYNC
- DISABLE_MAIL_WORKER
- QUARANTINE_FILE
- REVOKE_USER_SESSIONS
- FORCE_PASSWORD_RESET
- TEMP_BLOCK_IP

### 高風險，需二人覆核

- RESTORE_SNAPSHOT
- ENTER_SUPERWEAK
- KEEP_SUPERWEAK_DIRTY_STATE
- APPROVE_HIGH_RISK_INTEGRITY_FINDING
- DELETE_USER
- MASS_ROLE_CHANGE
- ROTATE_MAINTENANCE_BYPASS_TOKEN

### 永久禁止

- RUN_SHELL_COMMAND
- RUN_SQL
- READ_SECRET
- MODIFY_ROOT_PASSWORD
- DELETE_AUDIT_LOG
- DISABLE_INTEGRITY_GUARD
- DOWNLOAD_PRIVATE_FILE
- DECRYPT_E2EE_FILE
- MODIFY_SMTP_SECRET
- MODIFY_DISCORD_TOKEN

---

## 8. OpenClaw / Ollama / LM Studio

### Dryrun

```bash
export AI_LLM_PROVIDER=dryrun
```

### Ollama

```bash
ollama serve
ollama pull llama3.1

export AI_LLM_PROVIDER=ollama
export AI_LLM_BASE_URL=http://127.0.0.1:11434
export AI_LLM_MODEL=llama3.1
```

### LM Studio

啟用 LM Studio Local Server，通常：

```text
http://127.0.0.1:1234
```

設定：

```bash
export AI_LLM_PROVIDER=lmstudio
export AI_LLM_BASE_URL=http://127.0.0.1:1234
export AI_LLM_MODEL=local-model
```

### OpenClaw

建議架構：

```text
AI_web_exp_project
  → OpenClaw Gateway
  → Ollama / LM Studio
```

若 OpenClaw 提供 HTTP / OpenAI-compatible endpoint：

```bash
export AI_LLM_PROVIDER=openai_compatible
export AI_LLM_BASE_URL=http://127.0.0.1:18789/v1
export AI_LLM_MODEL=openclaw-local
```

若 OpenClaw 只有 WebSocket：

```text
ws://127.0.0.1:18789
```

MVP 先透過 local HTTP relay / adapter；下一階段再引入 WebSocket client dependency。

---

## 9. MVP 驗收

必跑：

```bash
python3 scripts/ai_mvp_smoke.py
PYTHONPATH=. python3 -m pytest -q tests/test_ai_mvp.py
```

必須證明：

- AI schema 可建立
- redaction 可遮罩 secrets
- dryrun provider 可運作
- AI analysis report 可生成
- AI proposal 可生成
- AI executor 可執行低風險 action
- AI executor 拒絕 forbidden action
- AI executor 拒絕 root-protected user target

---

## 10. 下一階段

MVP 之後再做：

- WebSocket OpenClaw client
- 完整 UI tab
- two-person approval integration
- root alert integration
- release_check integration
- AI incident playbook
