# Patch Instructions

## 自動套用

```bash
python3 overlay/scripts/apply_ai_mvp_overlay.py --repo .
```

## 手動套用

```bash
cp -R overlay/services/* services/
cp -R overlay/routes/* routes/
cp -R overlay/scripts/* scripts/
cp -R overlay/tests/* tests/
cp -R overlay/docs/* docs/
cp -R overlay/public/* public/
cp -R overlay/database/* database/
cp overlay/.env.ai.example .
```

修改 `routes/operations.py`：

```python
from routes.ai_control import register_ai_control_routes
```

在 `register_operation_routes` 內：

```python
register_ai_control_routes(app, deps)
```

## 驗收

```bash
python3 scripts/ai_mvp_smoke.py
PYTHONPATH=. python3 -m pytest -q tests/test_ai_mvp.py
```
