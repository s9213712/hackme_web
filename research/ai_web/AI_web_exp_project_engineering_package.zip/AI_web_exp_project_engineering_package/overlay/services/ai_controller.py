from __future__ import annotations

import json

from services.ai_schema import ensure_ai_schema, get_setting, now_iso
from services.ai_redaction import dumps_redacted, redact_obj, redact_text
from services.ai_llm_client import AIChatClient, load_ai_provider_config


def _table_exists(conn, name: str) -> bool:
    try:
        row = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone()
        return bool(row)
    except Exception:
        return False


def _count(conn, table: str, where: str = "", params=()) -> int:
    if not _table_exists(conn, table):
        return 0
    sql = f"SELECT COUNT(*) AS c FROM {table}"
    if where:
        sql += f" WHERE {where}"
    row = conn.execute(sql, tuple(params)).fetchone()
    return int(row["c"] if hasattr(row, "keys") else row[0])


def _recent_rows(conn, table: str, limit: int = 20):
    if not _table_exists(conn, table):
        return []
    try:
        rows = conn.execute(f"SELECT * FROM {table} ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall()
        return [dict(row) if hasattr(row, "keys") else list(row) for row in rows]
    except Exception:
        return []


class AIController:
    def __init__(self, *, conn, actor=None):
        self.conn = conn
        self.actor = actor or {}
        ensure_ai_schema(conn)

    def is_enabled(self) -> bool:
        import os
        env_enabled = str(os.environ.get("AI_CONTROLLER_ENABLED", "")).lower() in {"1", "true", "yes", "on"}
        return env_enabled or bool(get_setting(self.conn, "ai_controller_enabled", False))

    def status(self) -> dict:
        return {
            "ok": True,
            "enabled": self.is_enabled(),
            "mode": get_setting(self.conn, "ai_mode", "assistive"),
            "provider": get_setting(self.conn, "ai_llm_provider", "dryrun"),
            "reports": _count(self.conn, "ai_analysis_reports"),
            "proposals": _count(self.conn, "ai_action_proposals"),
            "pending_proposals": _count(self.conn, "ai_action_proposals", "status='proposed'"),
            "redaction": bool(get_setting(self.conn, "ai_redact_secrets", True)),
        }

    def collect_context(self) -> dict:
        context = {
            "generated_at": now_iso(),
            "counts": {
                "security_events": _count(self.conn, "security_events"),
                "integrity_findings_pending": _count(self.conn, "integrity_findings", "status='pending'"),
                "integrity_findings_high_pending": _count(self.conn, "integrity_findings", "status='pending' AND risk_level='high'"),
                "snapshots": _count(self.conn, "snapshots"),
                "ai_reports": _count(self.conn, "ai_analysis_reports"),
                "ai_proposals_pending": _count(self.conn, "ai_action_proposals", "status='proposed'"),
            },
            "recent_security_events": _recent_rows(self.conn, "security_events", 30),
            "recent_integrity_findings": _recent_rows(self.conn, "integrity_findings", 30),
            "recent_snapshots": _recent_rows(self.conn, "snapshots", 10),
            "ai_settings": {
                "ai_mode": get_setting(self.conn, "ai_mode", "assistive"),
                "ai_controller_enabled": get_setting(self.conn, "ai_controller_enabled", False),
                "ai_llm_provider": get_setting(self.conn, "ai_llm_provider", "dryrun"),
            },
        }
        return redact_obj(context)

    def run_analysis(self, *, report_type: str = "health_diagnosis", purpose: str = "manual") -> dict:
        if not self.is_enabled():
            return {"ok": False, "msg": "AI controller is disabled"}

        context = self.collect_context()
        system_prompt = (
            "You are an AI operations assistant for a security-focused Flask web platform. "
            "You only see redacted context. Never ask for raw secrets. "
            "Do not suggest touching the root account. "
            "Return Markdown with: summary, findings, risk level, recommended actions, actions requiring root approval."
        )
        user_prompt = "Analyze this redacted system context:\n\n" + json.dumps(context, ensure_ascii=False, indent=2, default=str)
        client = AIChatClient(load_ai_provider_config(self.conn))

        try:
            output = client.analyze(system_prompt=system_prompt, user_prompt=user_prompt)
            risk_level = self._infer_risk(context, output)
        except Exception as exc:
            output = f"## AI Analysis Failed\n\n{redact_text(str(exc))}"
            risk_level = "medium"

        cur = self.conn.execute(
            """
            INSERT INTO ai_analysis_reports
            (session_id, report_type, input_summary, output_markdown, risk_level, created_by, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                None,
                report_type,
                dumps_redacted({"purpose": purpose, "context_counts": context.get("counts", {})}),
                output,
                risk_level,
                int(self.actor.get("id") or 0),
                now_iso(),
            ),
        )
        report_id = int(cur.lastrowid)
        self._maybe_create_default_proposals(report_id, context)
        self.conn.commit()
        return {"ok": True, "report_id": report_id, "risk_level": risk_level, "output_markdown": output}

    def _infer_risk(self, context: dict, output: str) -> str:
        counts = context.get("counts", {})
        if int(counts.get("integrity_findings_high_pending") or 0) > 0:
            return "high"
        if int(counts.get("integrity_findings_pending") or 0) > 0:
            return "medium"
        return "low"

    def _maybe_create_default_proposals(self, report_id: int, context: dict) -> None:
        self.create_proposal(
            report_id=report_id,
            action_type="RUN_HEALTH_CHECK",
            payload={},
            rationale="Health check is a safe first diagnostic action.",
        )
        if int(context.get("counts", {}).get("integrity_findings_pending") or 0) > 0:
            self.create_proposal(
                report_id=report_id,
                action_type="RUN_INTEGRITY_RESCAN",
                payload={},
                rationale="Pending integrity findings exist; rescan can refresh current state.",
            )

    def create_proposal(self, *, report_id: int | None, action_type: str, payload: dict, rationale: str) -> int:
        from services.ai_action_registry import get_action_spec
        spec = get_action_spec(action_type)
        cur = self.conn.execute(
            """
            INSERT INTO ai_action_proposals
            (session_id, report_id, action_type, proposed_payload_json, rationale, risk_level,
             required_approval_level, status, proposed_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'proposed', ?)
            """,
            (
                None,
                report_id,
                spec.action_type,
                dumps_redacted(payload),
                rationale,
                spec.risk_level,
                spec.required_approval_level,
                now_iso(),
            ),
        )
        return int(cur.lastrowid)

    def list_reports(self, limit: int = 50) -> list[dict]:
        rows = self.conn.execute("SELECT * FROM ai_analysis_reports ORDER BY id DESC LIMIT ?", (max(1, min(int(limit), 200)),)).fetchall()
        return [dict(row) if hasattr(row, "keys") else list(row) for row in rows]

    def list_proposals(self, limit: int = 100) -> list[dict]:
        rows = self.conn.execute("SELECT * FROM ai_action_proposals ORDER BY id DESC LIMIT ?", (max(1, min(int(limit), 500)),)).fetchall()
        return [dict(row) if hasattr(row, "keys") else list(row) for row in rows]
