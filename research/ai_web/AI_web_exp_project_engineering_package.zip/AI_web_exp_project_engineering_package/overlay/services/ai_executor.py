from __future__ import annotations

import json

from services.ai_action_registry import ActionValidationError, validate_action_request
from services.ai_redaction import dumps_redacted, redact_text
from services.ai_schema import ensure_ai_schema, now_iso, set_setting


class AIExecutor:
    def __init__(self, *, conn, actor=None, callbacks=None):
        self.conn = conn
        self.actor = actor or {}
        self.callbacks = callbacks or {}
        ensure_ai_schema(conn)

    def record_tool_event(self, *, action_type: str, status: str, input_payload: dict, output_payload: dict) -> None:
        self.conn.execute(
            """
            INSERT INTO ai_tool_events
            (session_id, tool_name, action_type, status, redacted_input_json, redacted_output_json, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                None,
                "ai_executor",
                action_type,
                status,
                dumps_redacted(input_payload),
                dumps_redacted(output_payload),
                now_iso(),
            ),
        )

    def execute(self, *, action_type: str, payload: dict | None = None, approved: bool = False) -> dict:
        payload = payload or {}
        try:
            spec = validate_action_request(self.conn, action_type, payload)
            if spec.required_approval_level != "none" and not approved:
                raise ActionValidationError(f"{spec.action_type} requires approval level: {spec.required_approval_level}")

            if spec.action_type == "RUN_HEALTH_CHECK":
                result = self._run_health_check()
            elif spec.action_type == "CREATE_DIAGNOSTIC_REPORT":
                result = self._create_diagnostic_report(payload)
            elif spec.action_type == "SUMMARIZE_SECURITY_EVENTS":
                result = self._summarize_security_events()
            elif spec.action_type == "RUN_INTEGRITY_RESCAN":
                result = self._run_integrity_rescan()
            elif spec.action_type == "RUN_RETENTION_DRY_RUN":
                result = {"ok": True, "dry_run": True, "msg": "Retention dry-run placeholder completed."}
            elif spec.action_type == "ENABLE_MAINTENANCE_MODE":
                result = self._enable_maintenance_mode(payload)
            else:
                result = {"ok": False, "msg": f"Action {spec.action_type} is valid but not implemented in MVP executor."}

            status = "success" if result.get("ok") else "failed"
            self.record_tool_event(action_type=spec.action_type, status=status, input_payload=payload, output_payload=result)
            self.conn.commit()
            return result
        except Exception as exc:
            result = {"ok": False, "msg": redact_text(str(exc))}
            self.record_tool_event(action_type=str(action_type), status="denied", input_payload=payload, output_payload=result)
            self.conn.commit()
            return result

    def execute_proposal(self, proposal_id: int) -> dict:
        row = self.conn.execute("SELECT * FROM ai_action_proposals WHERE id=?", (int(proposal_id),)).fetchone()
        if not row:
            return {"ok": False, "msg": "proposal not found"}
        proposal = dict(row) if hasattr(row, "keys") else {}
        if proposal.get("status") not in {"approved", "proposed"}:
            return {"ok": False, "msg": "proposal is not executable"}
        approved = proposal.get("required_approval_level") == "none" or proposal.get("status") == "approved"
        try:
            payload = json.loads(proposal.get("proposed_payload_json") or "{}")
        except Exception:
            payload = {}
        result = self.execute(action_type=proposal["action_type"], payload=payload, approved=approved)
        self.conn.execute(
            """
            UPDATE ai_action_proposals
            SET status=?, executed_by=?, executed_at=?, execution_result_json=?, error_message=?
            WHERE id=?
            """,
            (
                "executed" if result.get("ok") else "failed",
                int(self.actor.get("id") or 0),
                now_iso(),
                dumps_redacted(result),
                None if result.get("ok") else result.get("msg"),
                int(proposal_id),
            ),
        )
        self.conn.commit()
        return result

    def _run_health_check(self) -> dict:
        counts = {}
        for table in ("users", "security_events", "integrity_findings", "snapshots", "ai_analysis_reports"):
            try:
                row = self.conn.execute(f"SELECT COUNT(*) AS c FROM {table}").fetchone()
                counts[table] = int(row["c"] if hasattr(row, "keys") else row[0])
            except Exception:
                counts[table] = None
        return {"ok": True, "health": {"counts": counts, "checked_at": now_iso()}}

    def _create_diagnostic_report(self, payload: dict) -> dict:
        title = str(payload.get("title") or "AI Diagnostic Report")
        body = str(payload.get("body") or "Diagnostic report created by AI executor MVP.")
        cur = self.conn.execute(
            """
            INSERT INTO ai_analysis_reports
            (session_id, report_type, input_summary, output_markdown, risk_level, created_by, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                None,
                "diagnostic_report",
                dumps_redacted({"title": title}),
                f"## {title}\n\n{body}",
                "low",
                int(self.actor.get("id") or 0),
                now_iso(),
            ),
        )
        return {"ok": True, "report_id": int(cur.lastrowid)}

    def _summarize_security_events(self) -> dict:
        try:
            rows = self.conn.execute("SELECT * FROM security_events ORDER BY id DESC LIMIT 20").fetchall()
            count = len(rows)
        except Exception:
            count = 0
        return {"ok": True, "summary": f"Recent security events available: {count}"}

    def _run_integrity_rescan(self) -> dict:
        callback = self.callbacks.get("integrity_rescan")
        if callable(callback):
            return callback()
        return {"ok": True, "msg": "Integrity rescan callback not configured; MVP no-op completed."}

    def _enable_maintenance_mode(self, payload: dict) -> dict:
        reason = str(payload.get("reason") or "AI-approved maintenance")
        set_setting(self.conn, "maintenance_mode", True, "bool")
        set_setting(self.conn, "maintenance_reason", reason, "str")
        return {"ok": True, "maintenance_mode": True, "reason": reason}
