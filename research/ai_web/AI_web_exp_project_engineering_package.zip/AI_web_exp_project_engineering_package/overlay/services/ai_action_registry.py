from __future__ import annotations

import ipaddress
from dataclasses import dataclass
from typing import Any

LOW_RISK = "low"
MEDIUM_RISK = "medium"
HIGH_RISK = "high"


@dataclass(frozen=True)
class ActionSpec:
    action_type: str
    risk_level: str
    required_approval_level: str
    required_fields: tuple[str, ...] = ()
    optional_fields: tuple[str, ...] = ()


ACTION_REGISTRY = {
    "RUN_HEALTH_CHECK": ActionSpec("RUN_HEALTH_CHECK", LOW_RISK, "none"),
    "RUN_INTEGRITY_RESCAN": ActionSpec("RUN_INTEGRITY_RESCAN", LOW_RISK, "none"),
    "CREATE_DIAGNOSTIC_REPORT": ActionSpec("CREATE_DIAGNOSTIC_REPORT", LOW_RISK, "none", optional_fields=("title", "body")),
    "SUMMARIZE_SECURITY_EVENTS": ActionSpec("SUMMARIZE_SECURITY_EVENTS", LOW_RISK, "none"),
    "RUN_RETENTION_DRY_RUN": ActionSpec("RUN_RETENTION_DRY_RUN", LOW_RISK, "none"),

    "ENABLE_MAINTENANCE_MODE": ActionSpec("ENABLE_MAINTENANCE_MODE", MEDIUM_RISK, "root", required_fields=("reason",), optional_fields=("eta",)),
    "DISABLE_DISCORD_SYNC": ActionSpec("DISABLE_DISCORD_SYNC", MEDIUM_RISK, "root", required_fields=("reason",)),
    "DISABLE_MAIL_WORKER": ActionSpec("DISABLE_MAIL_WORKER", MEDIUM_RISK, "root", required_fields=("reason",)),
    "QUARANTINE_FILE": ActionSpec("QUARANTINE_FILE", MEDIUM_RISK, "root", required_fields=("file_id", "reason")),
    "REVOKE_USER_SESSIONS": ActionSpec("REVOKE_USER_SESSIONS", MEDIUM_RISK, "root", required_fields=("user_id", "reason")),
    "FORCE_PASSWORD_RESET": ActionSpec("FORCE_PASSWORD_RESET", MEDIUM_RISK, "root", required_fields=("user_id", "reason")),
    "TEMP_BLOCK_IP": ActionSpec("TEMP_BLOCK_IP", MEDIUM_RISK, "root", required_fields=("ip", "duration_minutes", "reason")),

    "RESTORE_SNAPSHOT": ActionSpec("RESTORE_SNAPSHOT", HIGH_RISK, "two_person", required_fields=("snapshot_id", "reason")),
    "ENTER_SUPERWEAK": ActionSpec("ENTER_SUPERWEAK", HIGH_RISK, "two_person", required_fields=("reason",)),
    "KEEP_SUPERWEAK_DIRTY_STATE": ActionSpec("KEEP_SUPERWEAK_DIRTY_STATE", HIGH_RISK, "two_person", required_fields=("reason",)),
    "APPROVE_HIGH_RISK_INTEGRITY_FINDING": ActionSpec("APPROVE_HIGH_RISK_INTEGRITY_FINDING", HIGH_RISK, "two_person", required_fields=("finding_id", "reason")),
    "DELETE_USER": ActionSpec("DELETE_USER", HIGH_RISK, "two_person", required_fields=("user_id", "reason")),
    "MASS_ROLE_CHANGE": ActionSpec("MASS_ROLE_CHANGE", HIGH_RISK, "two_person", required_fields=("changes", "reason")),
    "ROTATE_MAINTENANCE_BYPASS_TOKEN": ActionSpec("ROTATE_MAINTENANCE_BYPASS_TOKEN", HIGH_RISK, "two_person", required_fields=("reason",)),
}

FORBIDDEN_ACTIONS = {
    "RUN_SHELL_COMMAND",
    "RUN_SQL",
    "READ_SECRET",
    "MODIFY_ROOT_PASSWORD",
    "DELETE_AUDIT_LOG",
    "DISABLE_INTEGRITY_GUARD",
    "DOWNLOAD_PRIVATE_FILE",
    "DECRYPT_E2EE_FILE",
    "MODIFY_SMTP_SECRET",
    "MODIFY_DISCORD_TOKEN",
}


class ActionValidationError(ValueError):
    pass


def get_action_spec(action_type: str) -> ActionSpec:
    action = str(action_type or "").strip().upper()
    if action in FORBIDDEN_ACTIONS:
        raise ActionValidationError(f"forbidden AI action: {action}")
    spec = ACTION_REGISTRY.get(action)
    if not spec:
        raise ActionValidationError(f"unknown AI action: {action}")
    return spec


def validate_payload_schema(spec: ActionSpec, payload: dict[str, Any]) -> None:
    if not isinstance(payload, dict):
        raise ActionValidationError("payload must be an object")
    for field in spec.required_fields:
        if field not in payload or payload[field] in (None, ""):
            raise ActionValidationError(f"missing required payload field: {field}")
    if spec.action_type == "TEMP_BLOCK_IP":
        try:
            ipaddress.ip_address(str(payload["ip"]))
        except Exception as exc:
            raise ActionValidationError("invalid ip") from exc
        duration = int(payload["duration_minutes"])
        if duration <= 0 or duration > 24 * 60:
            raise ActionValidationError("duration_minutes must be 1..1440")


def is_root_protected_user(conn, user_id: Any) -> bool:
    try:
        uid = int(user_id)
    except Exception:
        return False
    try:
        row = conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    except Exception:
        return False
    if not row:
        return False
    data = dict(row) if hasattr(row, "keys") else {}
    if str(data.get("username") or "").lower() == "root":
        return True
    if str(data.get("role") or "") == "super_admin":
        return True
    if int(data.get("is_root_protected") or 0) == 1:
        return True
    return False


def validate_action_request(conn, action_type: str, payload: dict[str, Any]) -> ActionSpec:
    spec = get_action_spec(action_type)
    validate_payload_schema(spec, payload)
    if "user_id" in payload and is_root_protected_user(conn, payload["user_id"]):
        raise ActionValidationError("AI action targets a root-protected user and is denied")
    return spec
