from __future__ import annotations

import json
import os
import urllib.request
import urllib.error
from dataclasses import dataclass

from services.ai_schema import get_setting


@dataclass
class AIProviderConfig:
    provider: str = "dryrun"
    base_url: str = ""
    model: str = ""
    timeout_seconds: int = 20


def load_ai_provider_config(conn=None) -> AIProviderConfig:
    provider = os.environ.get("AI_LLM_PROVIDER")
    base_url = os.environ.get("AI_LLM_BASE_URL")
    model = os.environ.get("AI_LLM_MODEL")
    timeout = os.environ.get("AI_LLM_TIMEOUT_SECONDS")

    if conn is not None:
        provider = provider or get_setting(conn, "ai_llm_provider", "dryrun")
        base_url = base_url or get_setting(conn, "ai_llm_base_url", "")
        model = model or get_setting(conn, "ai_llm_model", "")
        timeout = timeout or get_setting(conn, "ai_llm_timeout_seconds", 20)

    return AIProviderConfig(
        provider=str(provider or "dryrun").strip().lower(),
        base_url=str(base_url or "").rstrip("/"),
        model=str(model or "").strip(),
        timeout_seconds=int(timeout or 20),
    )


class AIClientError(RuntimeError):
    pass


class AIChatClient:
    def __init__(self, config: AIProviderConfig):
        self.config = config

    def analyze(self, *, system_prompt: str, user_prompt: str) -> str:
        provider = self.config.provider
        if provider in {"", "dryrun", "mock"}:
            return self._dryrun_response()
        if provider == "ollama":
            return self._ollama_chat(system_prompt, user_prompt)
        if provider in {"lmstudio", "openai_compatible", "openclaw_http"}:
            return self._openai_compatible_chat(system_prompt, user_prompt)
        raise AIClientError(f"unsupported provider: {provider}")

    def _dryrun_response(self) -> str:
        return (
            "## AI Dryrun Analysis\n\n"
            "- Provider: dryrun\n"
            "- 狀態：已收到 redacted context。\n"
            "- 風險：low\n"
            "- 建議：先執行 RUN_HEALTH_CHECK 與 CREATE_DIAGNOSTIC_REPORT。\n"
        )

    def _post_json(self, url: str, payload: dict) -> dict:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=self.config.timeout_seconds) as resp:
                body = resp.read().decode("utf-8", errors="replace")
                return json.loads(body)
        except urllib.error.HTTPError as exc:
            raise AIClientError(f"LLM HTTP error: {exc.code}") from exc
        except Exception as exc:
            raise AIClientError(f"LLM request failed: {exc}") from exc

    def _ollama_chat(self, system_prompt: str, user_prompt: str) -> str:
        base = self.config.base_url or "http://127.0.0.1:11434"
        model = self.config.model or "llama3.1"
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "stream": False,
        }
        data = self._post_json(f"{base}/api/chat", payload)
        return str((data.get("message") or {}).get("content") or "")

    def _openai_compatible_chat(self, system_prompt: str, user_prompt: str) -> str:
        base = self.config.base_url or "http://127.0.0.1:1234"
        if not base.endswith("/v1"):
            base = base + "/v1"
        model = self.config.model or "local-model"
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": 0.2,
        }
        data = self._post_json(f"{base}/chat/completions", payload)
        choices = data.get("choices") or []
        if not choices:
            return ""
        return str((choices[0].get("message") or {}).get("content") or "")
