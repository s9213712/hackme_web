from __future__ import annotations

import json
import re
from typing import Any

SENSITIVE_KEY_RE = re.compile(
    r"(?i)(password|passwd|pwd|secret|token|api[_-]?key|authorization|cookie|session|csrf|smtp|webhook|private[_-]?key)"
)

PATTERNS = [
    (re.compile(r"(?i)(Authorization\s*:\s*)(Bearer|Basic)\s+[A-Za-z0-9._~+/=-]+"), r"\1\2 <redacted>"),
    (re.compile(r"(?i)\bBearer\s+[A-Za-z0-9._~+/=-]{8,}"), "Bearer <redacted>"),
    (re.compile(r"(?i)(password|passwd|secret|token|api_key|access_token|refresh_token|csrf_token|session_id)\s*[:=]\s*[^,\s;}]+"), r"\1=<redacted>"),
    (re.compile(r"(?i)https://discord\.com/api/webhooks/[^\s\"']+"), "https://discord.com/api/webhooks/<redacted>"),
    (re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----", re.S), "-----BEGIN <redacted> PRIVATE KEY-----"),
    (re.compile(r"(?i)(mysql|postgres|postgresql|redis|mongodb)://[^\s\"']+"), r"\1://<redacted>"),
]


def redact_text(text: Any, max_len: int = 4000) -> str:
    value = "" if text is None else str(text)
    for regex, repl in PATTERNS:
        value = regex.sub(repl, value)
    if len(value) > max_len:
        value = value[:max_len] + "...<truncated>"
    return value


def redact_obj(value: Any, max_depth: int = 6) -> Any:
    if max_depth <= 0:
        return "<max-depth>"
    if isinstance(value, dict):
        out = {}
        for key, item in value.items():
            key_s = str(key)
            if SENSITIVE_KEY_RE.search(key_s):
                out[key_s] = "<redacted>"
            else:
                out[key_s] = redact_obj(item, max_depth=max_depth - 1)
        return out
    if isinstance(value, list):
        return [redact_obj(item, max_depth=max_depth - 1) for item in value[:200]]
    if isinstance(value, tuple):
        return tuple(redact_obj(item, max_depth=max_depth - 1) for item in value[:200])
    if isinstance(value, str):
        return redact_text(value)
    return value


def dumps_redacted(value: Any) -> str:
    return json.dumps(redact_obj(value), ensure_ascii=False, sort_keys=True, default=str)
