from __future__ import annotations

from datetime import datetime

AI_DEFAULT_SETTINGS = {
    "feature_ai_admin_lab_enabled": ("false", "bool"),
    "ai_controller_enabled": ("false", "bool"),
    "ai_mode": ("assistive", "str"),
    "ai_llm_provider": ("dryrun", "str"),
    "ai_llm_base_url": ("", "str"),
    "ai_llm_model": ("", "str"),
    "ai_llm_timeout_seconds": ("20", "int"),
    "ai_redact_secrets": ("true", "bool"),
    "ai_low_risk_auto_execute": ("false", "bool"),
    "ai_max_context_events": ("200", "int"),
}


def now_iso() -> str:
    return datetime.now().isoformat()


def ensure_ai_schema(conn) -> None:
    """Create AI MVP schema. Safe to call repeatedly."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS ai_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_by INTEGER,
            purpose TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'active',
            created_at TEXT NOT NULL,
            closed_at TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS ai_analysis_reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER,
            report_type TEXT NOT NULL,
            input_summary TEXT,
            output_markdown TEXT NOT NULL,
            risk_level TEXT NOT NULL DEFAULT 'low',
            created_by INTEGER,
            created_at TEXT NOT NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS ai_action_proposals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER,
            report_id INTEGER,
            action_type TEXT NOT NULL,
            target_type TEXT,
            target_id TEXT,
            proposed_payload_json TEXT NOT NULL,
            rationale TEXT,
            risk_level TEXT NOT NULL,
            required_approval_level TEXT NOT NULL DEFAULT 'root',
            status TEXT NOT NULL DEFAULT 'proposed',
            proposed_at TEXT NOT NULL,
            approved_by INTEGER,
            approved_at TEXT,
            executed_by INTEGER,
            executed_at TEXT,
            execution_result_json TEXT,
            error_message TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS ai_tool_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER,
            tool_name TEXT NOT NULL,
            action_type TEXT,
            status TEXT NOT NULL,
            redacted_input_json TEXT,
            redacted_output_json TEXT,
            created_at TEXT NOT NULL
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_ai_reports_created ON ai_analysis_reports(created_at)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_ai_proposals_status ON ai_action_proposals(status, risk_level, proposed_at)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_ai_tool_events_created ON ai_tool_events(created_at)")

    # Minimal compatibility for tests; real hackme_web already has system_settings.
    conn.execute("""
        CREATE TABLE IF NOT EXISTS system_settings (
            key TEXT PRIMARY KEY,
            value TEXT,
            value_type TEXT,
            updated_at TEXT
        )
    """)
    seed_ai_settings(conn)


def seed_ai_settings(conn) -> None:
    for key, (value, value_type) in AI_DEFAULT_SETTINGS.items():
        conn.execute(
            "INSERT OR IGNORE INTO system_settings (key, value, value_type, updated_at) VALUES (?, ?, ?, ?)",
            (key, value, value_type, now_iso()),
        )


def get_setting(conn, key: str, default=None):
    row = conn.execute("SELECT value, value_type FROM system_settings WHERE key=?", (key,)).fetchone()
    if not row:
        return default
    value = row["value"] if hasattr(row, "keys") else row[0]
    value_type = row["value_type"] if hasattr(row, "keys") else row[1]
    if value_type == "bool":
        return str(value).strip().lower() in {"1", "true", "yes", "on"}
    if value_type == "int":
        try:
            return int(value)
        except Exception:
            return default
    return value


def set_setting(conn, key: str, value, value_type: str | None = None) -> None:
    if value_type is None:
        if isinstance(value, bool):
            value_type = "bool"
            value = "true" if value else "false"
        elif isinstance(value, int):
            value_type = "int"
            value = str(value)
        else:
            value_type = "str"
            value = str(value)
    conn.execute(
        """
        INSERT INTO system_settings (key, value, value_type, updated_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(key) DO UPDATE SET value=excluded.value, value_type=excluded.value_type, updated_at=excluded.updated_at
        """,
        (key, str(value), value_type, now_iso()),
    )
