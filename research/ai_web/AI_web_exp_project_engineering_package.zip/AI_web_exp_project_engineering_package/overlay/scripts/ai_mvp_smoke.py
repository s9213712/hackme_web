#!/usr/bin/env python3
from __future__ import annotations

import sqlite3
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from services.ai_schema import ensure_ai_schema, set_setting
from services.ai_redaction import redact_text
from services.ai_controller import AIController
from services.ai_executor import AIExecutor


def main() -> int:
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    ensure_ai_schema(conn)
    conn.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT, role TEXT, is_root_protected INTEGER DEFAULT 0)")
    conn.execute("INSERT INTO users (id, username, role, is_root_protected) VALUES (1, 'root', 'super_admin', 1)")
    set_setting(conn, "ai_controller_enabled", True, "bool")
    set_setting(conn, "ai_llm_provider", "dryrun", "str")
    conn.commit()

    redacted = redact_text("password=hunter2 Authorization: Bearer abcdefghijklmnop")
    assert "hunter2" not in redacted
    assert "abcdefghijklmnop" not in redacted

    ctl = AIController(conn=conn, actor={"id": 1, "username": "root", "role": "super_admin"})
    result = ctl.run_analysis(report_type="smoke", purpose="smoke-test")
    assert result["ok"], result

    executor = AIExecutor(conn=conn, actor={"id": 1, "username": "root", "role": "super_admin"})
    health = executor.execute(action_type="RUN_HEALTH_CHECK", payload={})
    assert health["ok"], health

    forbidden = executor.execute(action_type="RUN_SHELL_COMMAND", payload={"command": "id"})
    assert not forbidden["ok"], forbidden

    root_target = executor.execute(action_type="REVOKE_USER_SESSIONS", payload={"user_id": 1, "reason": "test"}, approved=True)
    assert not root_target["ok"], root_target

    print("AI MVP smoke passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
