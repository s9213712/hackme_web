#!/usr/bin/env python3
from __future__ import annotations

import argparse
import shutil
from pathlib import Path


def copy_tree(src: Path, dst: Path) -> None:
    if not src.exists():
        return
    for item in src.rglob("*"):
        if item.is_dir():
            continue
        rel = item.relative_to(src)
        target = dst / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(item, target)


def patch_operations(repo: Path) -> None:
    path = repo / "routes" / "operations.py"
    if not path.exists():
        print("WARN: routes/operations.py not found; register routes.ai_control manually.")
        return
    text = path.read_text(encoding="utf-8")
    if "register_ai_control_routes" not in text:
        text = "from routes.ai_control import register_ai_control_routes\n" + text
    marker = "def register_operation_routes(app, deps):"
    if marker in text and "register_ai_control_routes(app, deps)" not in text:
        lines = text.splitlines()
        out = []
        for line in lines:
            out.append(line)
            if line.strip() == marker:
                out.append("    register_ai_control_routes(app, deps)")
        text = "\n".join(out) + "\n"
    path.write_text(text, encoding="utf-8")
    print("patched routes/operations.py")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", default=".", help="Path to hackme_web repo root")
    parser.add_argument("--overlay", default=None, help="Path to overlay directory")
    parser.add_argument("--patch-routes", action="store_true", default=True)
    args = parser.parse_args()

    repo = Path(args.repo).resolve()
    overlay = Path(args.overlay).resolve() if args.overlay else Path(__file__).resolve().parents[1]

    for folder in ("services", "routes", "scripts", "tests", "docs", "public", "database"):
        copy_tree(overlay / folder, repo / folder)
        print(f"copied {folder}")

    env_src = overlay / ".env.ai.example"
    if env_src.exists():
        shutil.copy2(env_src, repo / ".env.ai.example")
        print("copied .env.ai.example")

    if args.patch_routes:
        patch_operations(repo)

    print("AI MVP overlay applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
