CREATE TABLE IF NOT EXISTS ai_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_by INTEGER,
    purpose TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL,
    closed_at TEXT
);

CREATE TABLE IF NOT EXISTS ai_analysis_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER,
    report_type TEXT NOT NULL,
    input_summary TEXT,
    output_markdown TEXT NOT NULL,
    risk_level TEXT NOT NULL DEFAULT 'low',
    created_by INTEGER,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS ai_action_proposals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER,
    report_id INTEGER,
    action_type TEXT NOT NULL,
    target_type TEXT,
    target_id TEXT,
    proposed_payload_json TEXT NOT NULL,
    rationale TEXT,
    risk_level TEXT NOT NULL,
    required_approval_level TEXT NOT NULL DEFAULT 'root',
    status TEXT NOT NULL DEFAULT 'proposed',
    proposed_at TEXT NOT NULL,
    approved_by INTEGER,
    approved_at TEXT,
    executed_by INTEGER,
    executed_at TEXT,
    execution_result_json TEXT,
    error_message TEXT
);

CREATE TABLE IF NOT EXISTS ai_tool_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER,
    tool_name TEXT NOT NULL,
    action_type TEXT,
    status TEXT NOT NULL,
    redacted_input_json TEXT,
    redacted_output_json TEXT,
    created_at TEXT NOT NULL
);
