from __future__ import annotations

import sqlite3
import pytest

from services.ai_schema import ensure_ai_schema, set_setting
from services.ai_redaction import redact_text, redact_obj
from services.ai_action_registry import ActionValidationError, validate_action_request
from services.ai_controller import AIController
from services.ai_executor import AIExecutor


@pytest.fixture()
def conn():
    c = sqlite3.connect(":memory:")
    c.row_factory = sqlite3.Row
    ensure_ai_schema(c)
    c.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT, role TEXT, is_root_protected INTEGER DEFAULT 0)")
    c.execute("INSERT INTO users (id, username, role, is_root_protected) VALUES (1, 'root', 'super_admin', 1)")
    c.execute("INSERT INTO users (id, username, role, is_root_protected) VALUES (2, 'alice', 'user', 0)")
    set_setting(c, "ai_controller_enabled", True, "bool")
    set_setting(c, "ai_llm_provider", "dryrun", "str")
    c.commit()
    return c


def test_redaction_masks_secrets():
    text = "password=hunter2 Authorization: Bearer abcdefghijklmnop https://discord.com/api/webhooks/123/secret"
    redacted = redact_text(text)
    assert "hunter2" not in redacted
    assert "abcdefghijklmnop" not in redacted
    assert "/123/secret" not in redacted


def test_redaction_object_masks_sensitive_keys():
    data = redact_obj({"smtp_password": "secret", "safe": "ok"})
    assert data["smtp_password"] == "<redacted>"
    assert data["safe"] == "ok"


def test_forbidden_action_rejected(conn):
    with pytest.raises(ActionValidationError):
        validate_action_request(conn, "RUN_SHELL_COMMAND", {"command": "id"})


def test_root_protected_target_rejected(conn):
    with pytest.raises(ActionValidationError):
        validate_action_request(conn, "REVOKE_USER_SESSIONS", {"user_id": 1, "reason": "test"})


def test_normal_user_target_allowed(conn):
    spec = validate_action_request(conn, "REVOKE_USER_SESSIONS", {"user_id": 2, "reason": "test"})
    assert spec.action_type == "REVOKE_USER_SESSIONS"


def test_dryrun_analysis_creates_report(conn):
    ctl = AIController(conn=conn, actor={"id": 1, "username": "root", "role": "super_admin"})
    result = ctl.run_analysis(report_type="unit", purpose="test")
    assert result["ok"]
    assert result["report_id"] >= 1


def test_executor_health_check(conn):
    executor = AIExecutor(conn=conn, actor={"id": 1, "username": "root", "role": "super_admin"})
    result = executor.execute(action_type="RUN_HEALTH_CHECK", payload={})
    assert result["ok"]


def test_executor_rejects_unapproved_medium_risk(conn):
    executor = AIExecutor(conn=conn, actor={"id": 1, "username": "root", "role": "super_admin"})
    result = executor.execute(action_type="ENABLE_MAINTENANCE_MODE", payload={"reason": "test"})
    assert not result["ok"]
