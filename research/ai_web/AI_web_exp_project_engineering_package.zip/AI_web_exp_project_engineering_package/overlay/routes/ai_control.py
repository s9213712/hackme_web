from __future__ import annotations

from flask import request

from services.ai_controller import AIController
from services.ai_executor import AIExecutor
from services.ai_schema import ensure_ai_schema, set_setting, now_iso


def register_ai_control_routes(app, deps):
    get_current_user_ctx = deps["get_current_user_ctx"]
    get_db = deps["get_db"]
    json_resp = deps["json_resp"]
    require_csrf_safe = deps.get("require_csrf_safe", lambda f: f)
    audit = deps.get("audit", lambda *args, **kwargs: None)

    def _root_or_403():
        actor = get_current_user_ctx()
        if not actor:
            return None, json_resp({"ok": False, "msg": "請先登入"}, 401)
        if actor.get("role") != "super_admin":
            return None, json_resp({"ok": False, "msg": "需要 root 權限"}, 403)
        return actor, None

    @app.route("/api/root/ai/status", methods=["GET"])
    @require_csrf_safe
    def ai_status():
        actor, err = _root_or_403()
        if err:
            return err
        conn = get_db()
        try:
            ensure_ai_schema(conn)
            ctl = AIController(conn=conn, actor=actor)
            return json_resp(ctl.status())
        finally:
            conn.close()

    @app.route("/api/root/ai/analyze", methods=["POST"])
    @require_csrf_safe
    def ai_analyze():
        actor, err = _root_or_403()
        if err:
            return err
        data = request.get_json(silent=True) or {}
        conn = get_db()
        try:
            ensure_ai_schema(conn)
            ctl = AIController(conn=conn, actor=actor)
            result = ctl.run_analysis(
                report_type=str(data.get("report_type") or "health_diagnosis"),
                purpose=str(data.get("purpose") or "manual"),
            )
            audit("AI_ANALYZE", "-", user=actor.get("username"), success=bool(result.get("ok")), detail=f"report_type={data.get('report_type') or 'health_diagnosis'}")
            return json_resp(result, 200 if result.get("ok") else 400)
        finally:
            conn.close()

    @app.route("/api/root/ai/reports", methods=["GET"])
    @require_csrf_safe
    def ai_reports():
        actor, err = _root_or_403()
        if err:
            return err
        conn = get_db()
        try:
            ensure_ai_schema(conn)
            ctl = AIController(conn=conn, actor=actor)
            return json_resp({"ok": True, "reports": ctl.list_reports()})
        finally:
            conn.close()

    @app.route("/api/root/ai/proposals", methods=["GET"])
    @require_csrf_safe
    def ai_proposals():
        actor, err = _root_or_403()
        if err:
            return err
        conn = get_db()
        try:
            ensure_ai_schema(conn)
            ctl = AIController(conn=conn, actor=actor)
            return json_resp({"ok": True, "proposals": ctl.list_proposals()})
        finally:
            conn.close()

    @app.route("/api/root/ai/proposals/<int:proposal_id>/approve", methods=["POST"])
    @require_csrf_safe
    def ai_approve_proposal(proposal_id):
        actor, err = _root_or_403()
        if err:
            return err
        data = request.get_json(silent=True) or {}
        conn = get_db()
        try:
            ensure_ai_schema(conn)
            row = conn.execute("SELECT * FROM ai_action_proposals WHERE id=?", (int(proposal_id),)).fetchone()
            if not row:
                return json_resp({"ok": False, "msg": "proposal not found"}, 404)
            proposal = dict(row)
            if proposal.get("status") != "proposed":
                return json_resp({"ok": False, "msg": "proposal is not proposed"}, 400)
            if proposal.get("risk_level") in {"high", "critical"} and data.get("confirm") != "APPROVE_AI_HIGH_RISK":
                return json_resp({"ok": False, "msg": "high risk proposal requires confirm=APPROVE_AI_HIGH_RISK"}, 400)
            conn.execute(
                "UPDATE ai_action_proposals SET status='approved', approved_by=?, approved_at=? WHERE id=?",
                (int(actor.get("id") or 0), now_iso(), int(proposal_id)),
            )
            conn.commit()
            audit("AI_PROPOSAL_APPROVED", "-", user=actor.get("username"), success=True, detail=f"proposal_id={proposal_id},action={proposal.get('action_type')}")
            return json_resp({"ok": True, "msg": "approved"})
        finally:
            conn.close()

    @app.route("/api/root/ai/proposals/<int:proposal_id>/execute", methods=["POST"])
    @require_csrf_safe
    def ai_execute_proposal(proposal_id):
        actor, err = _root_or_403()
        if err:
            return err
        conn = get_db()
        try:
            ensure_ai_schema(conn)
            executor = AIExecutor(conn=conn, actor=actor)
            result = executor.execute_proposal(int(proposal_id))
            audit("AI_PROPOSAL_EXECUTED", "-", user=actor.get("username"), success=bool(result.get("ok")), detail=f"proposal_id={proposal_id}")
            return json_resp(result, 200 if result.get("ok") else 400)
        finally:
            conn.close()

    @app.route("/api/root/ai/kill-switch", methods=["POST"])
    @require_csrf_safe
    def ai_kill_switch():
        actor, err = _root_or_403()
        if err:
            return err
        data = request.get_json(silent=True) or {}
        enabled = bool(data.get("enabled"))
        conn = get_db()
        try:
            ensure_ai_schema(conn)
            set_setting(conn, "ai_controller_enabled", enabled, "bool")
            conn.commit()
            audit("AI_KILL_SWITCH", "-", user=actor.get("username"), success=True, detail=f"enabled={enabled}")
            return json_resp({"ok": True, "ai_controller_enabled": enabled})
        finally:
            conn.close()
