# OpenClaw Connection

## Ollama

```bash
ollama serve
ollama pull llama3.1
export AI_LLM_PROVIDER=ollama
export AI_LLM_BASE_URL=http://127.0.0.1:11434
export AI_LLM_MODEL=llama3.1
```

## LM Studio

```bash
export AI_LLM_PROVIDER=lmstudio
export AI_LLM_BASE_URL=http://127.0.0.1:1234
export AI_LLM_MODEL=local-model
```

## OpenClaw

```bash
export AI_LLM_PROVIDER=openai_compatible
export AI_LLM_BASE_URL=http://127.0.0.1:18789/v1
export AI_LLM_MODEL=openclaw-local
```

WebSocket gateway 請先透過 HTTP relay。
