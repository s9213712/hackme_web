# AI Controlled System

## 用途

Root-only AI assistant：

- audit analysis
- security event summary
- integrity review
- health diagnosis
- action proposal
- low-risk executor

## Root-only

所有 API 必須只允許 `super_admin`。

## 禁止

- root operation
- raw secrets
- shell
- SQL
- private files
- E2EE decrypt

## API

```text
GET  /api/root/ai/status
POST /api/root/ai/analyze
GET  /api/root/ai/reports
GET  /api/root/ai/proposals
POST /api/root/ai/proposals/<id>/approve
POST /api/root/ai/proposals/<id>/execute
POST /api/root/ai/kill-switch
```
