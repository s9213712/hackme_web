window.AIControlMVP = {
  async status() {
    const res = await fetch('/api/root/ai/status', { credentials: 'same-origin' });
    return await res.json();
  },

  async analyze(csrfToken, reportType = 'health_diagnosis') {
    const res = await fetch('/api/root/ai/analyze', {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrfToken || ''
      },
      body: JSON.stringify({ report_type: reportType, purpose: 'manual-ui' })
    });
    return await res.json();
  },

  async reports() {
    const res = await fetch('/api/root/ai/reports', { credentials: 'same-origin' });
    return await res.json();
  },

  async proposals() {
    const res = await fetch('/api/root/ai/proposals', { credentials: 'same-origin' });
    return await res.json();
  }
};
