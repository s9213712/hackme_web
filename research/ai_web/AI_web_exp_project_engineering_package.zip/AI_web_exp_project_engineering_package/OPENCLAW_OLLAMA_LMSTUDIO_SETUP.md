# OpenClaw / Ollama / LM Studio 設定

## Dryrun

```bash
export AI_LLM_PROVIDER=dryrun
```

## Ollama

```bash
ollama serve
ollama pull llama3.1

export AI_LLM_PROVIDER=ollama
export AI_LLM_BASE_URL=http://127.0.0.1:11434
export AI_LLM_MODEL=llama3.1
```

## LM Studio

啟用 LM Studio Local Server：

```text
http://127.0.0.1:1234
```

```bash
export AI_LLM_PROVIDER=lmstudio
export AI_LLM_BASE_URL=http://127.0.0.1:1234
export AI_LLM_MODEL=local-model
```

## OpenClaw

推薦：

```text
AI Controller → OpenClaw Gateway → Ollama / LM Studio
```

如果 OpenClaw 提供 HTTP / OpenAI-compatible：

```bash
export AI_LLM_PROVIDER=openai_compatible
export AI_LLM_BASE_URL=http://127.0.0.1:18789/v1
export AI_LLM_MODEL=openclaw-local
```

如果 OpenClaw 是 WebSocket：

```text
ws://127.0.0.1:18789
```

MVP 請先用 HTTP relay；下一階段再加入 WebSocket client。
